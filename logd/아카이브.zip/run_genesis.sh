#!/bin/bash
geth --datadir="./private_chain" init genesis.json
